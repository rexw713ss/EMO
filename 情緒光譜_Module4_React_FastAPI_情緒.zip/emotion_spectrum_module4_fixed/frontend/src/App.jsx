import { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from 'recharts';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000';

// 與隊友統一的情緒代碼：資料傳輸用英文 key，畫面顯示用中文 label。
const EMOTION_META = {
  CALM: {
    label: '平靜',
    description: '柔和藍色漸層，慢速呼吸動畫',
  },
  JOY: {
    label: '愉悅',
    description: '黃色或橘色暖色動畫，輕快粒子流動',
  },
  ANXIOUS: {
    label: '緊張',
    description: '紅色受控脈衝，安全模式降低刺激',
  },
  DEPRESSED: {
    label: '低落',
    description: '紫色或低亮度流動背景，慢速轉場',
  },
};

const emotions = Object.keys(EMOTION_META);

const defaultBaseline = {
  mouth_corner_delta: 0,
  eye_open_degree: 0,
  brow_angle: 0,
  head_pitch: 0,
  head_yaw: 0,
  landmark_variance: 0,
};

const defaultProbabilities = {
  CALM: 25,
  JOY: 25,
  ANXIOUS: 25,
  DEPRESSED: 25,
};

function getEmotionLabel(emotion) {
  return EMOTION_META[emotion]?.label || emotion || '尚無資料';
}

function getEmotionDescription(emotion) {
  return EMOTION_META[emotion]?.description || '尚無視覺結果';
}

function formatTime(isoText) {
  if (!isoText) return '';
  const date = new Date(isoText);
  return date.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

async function apiRequest(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(data?.detail || 'API 發生錯誤');
  }
  return data;
}

export default function App() {
  const [subjectId, setSubjectId] = useState('SUBJECT_001');
  const [baseline, setBaseline] = useState(defaultBaseline);
  const [probabilities, setProbabilities] = useState(defaultProbabilities);
  const [state, setState] = useState(null);
  const [message, setMessage] = useState('請先完成校正，再接收 Module II 的情緒結果。');
  const [loading, setLoading] = useState(false);

  const lastResult = state?.lastResult || null;
  const history = state?.history || [];
  const trendSummary = state?.trendSummary || null;

  const confidenceChartData = useMemo(() => {
    const confidence = lastResult?.confidence || defaultProbabilities;
    return emotions.map((emotion) => ({
      emotion,
      name: EMOTION_META[emotion].label,
      value: confidence[emotion] || 0,
    }));
  }, [lastResult]);

  const trendChartData = useMemo(() => {
    return history.map((item) => {
      const row = {
        time: formatTime(item.createdAt),
        mainEmotion: item.emotion,
        mainEmotionLabel: getEmotionLabel(item.emotion),
      };
      emotions.forEach((emotion) => {
        row[emotion] = item.confidence?.[emotion] || 0;
      });
      return row;
    });
  }, [history]);

  const visualStyle = lastResult?.safetyConfig || {
    palette: ['#111827', '#374151'],
    animationSpeedMs: 3000,
    brightness: 0.85,
    contrast: 0.7,
    pulseIntensity: 0.12,
  };

  const previewStyle = {
    '--color-a': visualStyle.palette?.[0] || '#111827',
    '--color-b': visualStyle.palette?.[1] || '#374151',
    '--animation-speed': `${visualStyle.animationSpeedMs || 3000}ms`,
    '--brightness': visualStyle.brightness || 0.85,
    '--contrast': visualStyle.contrast || 0.7,
  };

  async function refreshState(id = subjectId) {
    const data = await apiRequest(`/api/state/${encodeURIComponent(id)}`);
    setState(data);
    return data;
  }

  async function handleCalibration() {
    setLoading(true);
    try {
      const data = await apiRequest('/api/calibration', {
        method: 'POST',
        body: JSON.stringify({ subjectId, baselineFeatures: baseline }),
      });
      setMessage(data.message);
      await refreshState(data.subjectId);
    } catch (error) {
      setMessage(`校正失敗：${error.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleEmotionUpdate() {
    setLoading(true);
    try {
      const data = await apiRequest('/api/emotion', {
        method: 'POST',
        body: JSON.stringify({ subjectId, probabilities, source: 'module_ii' }),
      });
      if (data.paused) {
        setMessage(data.message);
        await refreshState(subjectId);
        return;
      }
      setState({
        subjectId,
        calibrated: true,
        paused: false,
        displayMode: data.result.displayMode,
        lastResult: data.result,
        history: data.history,
        trendSummary: data.trendSummary,
      });
      setMessage('已接收 Module II 情緒結果，Dashboard 已更新。');
    } catch (error) {
      setMessage(`更新失敗：${error.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function handlePause(paused) {
    setLoading(true);
    try {
      const data = await apiRequest('/api/pause', {
        method: 'POST',
        body: JSON.stringify({ subjectId, paused }),
      });
      setMessage(data.message);
      await refreshState(subjectId);
    } catch (error) {
      setMessage(`設定失敗：${error.message}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleMode(mode) {
    setLoading(true);
    try {
      await apiRequest('/api/display-mode', {
        method: 'POST',
        body: JSON.stringify({ subjectId, mode }),
      });
      setMessage(mode === 'fullscreen' ? '已切換為全螢幕展示模式。' : '已切換為儀表板模式。');
      await refreshState(subjectId);
    } catch (error) {
      setMessage(`切換模式失敗：${error.message}`);
    } finally {
      setLoading(false);
    }
  }

  function downloadReport() {
    window.open(`${API_BASE}/api/report/${encodeURIComponent(subjectId)}`, '_blank');
  }

  return (
    <main className="page">
      <section className="hero">
        <div>
          <p className="eyebrow">Module 4 Dashboard & Management</p>
          <h1>情緒光譜</h1>
          <p className="subtitle">React 正式前端 × Python FastAPI 後台，情緒代碼已統一為 CALM / JOY / ANXIOUS / DEPRESSED。</p>
        </div>
        <div className="status-card">
          <span className={state?.paused ? 'dot paused' : 'dot'} />
          {state?.paused ? '暫停中' : state?.calibrated ? '分析待命 / 執行中' : '尚未校正'}
        </div>
      </section>

      <section className="notice">{message}</section>

      <section className="grid two">
        <div className="panel">
          <h2>1. 系統輸入與校正</h2>
          <label>
            受試者匿名編號
            <input value={subjectId} onChange={(event) => setSubjectId(event.target.value)} />
          </label>

          <div className="feature-grid">
            {Object.keys(defaultBaseline).map((key) => (
              <label key={key}>
                {key}
                <input
                  type="number"
                  step="0.01"
                  value={baseline[key]}
                  onChange={(event) => setBaseline({ ...baseline, [key]: Number(event.target.value) })}
                />
              </label>
            ))}
          </div>

          <button disabled={loading} onClick={handleCalibration}>開始校正</button>
          <p className="hint">正式版請由 Module I 傳入基準特徵。這裡不讀照片、不存影像。</p>
        </div>

        <div className="panel">
          <h2>2. Module II 情緒結果輸入</h2>
          <div className="feature-grid">
            {emotions.map((emotion) => (
              <label key={emotion}>
                {emotion} / {EMOTION_META[emotion].label} 信心度
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={probabilities[emotion]}
                  onChange={(event) => setProbabilities({ ...probabilities, [emotion]: Number(event.target.value) })}
                />
              </label>
            ))}
          </div>
          <button disabled={loading} onClick={handleEmotionUpdate}>送出情緒結果</button>
          <p className="hint">後端會把四個信心度正規化為 100%，並自動選出最高者作為主情緒。</p>
        </div>
      </section>

      <section className="grid three">
        <div className="panel metric">
          <span>目前情緒</span>
          <strong>{lastResult ? `${lastResult.emotion} / ${getEmotionLabel(lastResult.emotion)}` : '尚無資料'}</strong>
          <p>{getEmotionDescription(lastResult?.emotion)}</p>
        </div>
        <div className="panel metric">
          <span>平均最高信心度</span>
          <strong>{trendSummary ? `${trendSummary.averageTopConfidence}%` : '0%'}</strong>
          <p>{trendSummary?.note || '尚無趨勢資料'}</p>
        </div>
        <div className="panel metric">
          <span>情緒切換次數</span>
          <strong>{trendSummary?.switchCount ?? 0}</strong>
          <p>不把情緒當成 1～4 高低順序，只看類別變化。</p>
        </div>
      </section>

      <section className="grid two">
        <div className="panel chart-panel">
          <h2>信心度長條圖</h2>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={confidenceChartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="value" name="信心度 %" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="panel chart-panel">
          <h2>信心度時間軸</h2>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={trendChartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              {emotions.map((emotion) => (
                <Line
                  key={emotion}
                  type="monotone"
                  dataKey={emotion}
                  name={EMOTION_META[emotion].label}
                  dot={false}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="grid two">
        <div className="panel">
          <h2>互動視覺展示預覽</h2>
          <div className="visual-preview" style={previewStyle}>
            <div className="visual-orb" />
            <p>{getEmotionLabel(lastResult?.emotion)}</p>
          </div>
          <ul className="safe-list">
            <li>動畫速度：{visualStyle.animationSpeedMs || 0} ms</li>
            <li>亮度限制：{visualStyle.brightness || 0}</li>
            <li>對比限制：{visualStyle.contrast || 0}</li>
            <li>禁止快速閃爍：{visualStyle.flashAllowed === false ? '是' : '尚未套用'}</li>
          </ul>
        </div>

        <div className="panel">
          <h2>系統控制與報告</h2>
          <div className="button-row">
            <button disabled={loading} onClick={() => handlePause(true)}>暫停分析</button>
            <button disabled={loading} onClick={() => handlePause(false)}>繼續分析</button>
          </div>
          <div className="button-row">
            <button disabled={loading} onClick={() => handleMode('dashboard')}>儀表板模式</button>
            <button disabled={loading} onClick={() => handleMode('fullscreen')}>全螢幕展示模式</button>
          </div>
          <button disabled={loading} onClick={downloadReport}>匯出 CSV 報告</button>
          <p className="hint">CSV 由後端即時產生，檔名只使用安全處理過的匿名編號。</p>
        </div>
      </section>

      <section className="panel">
        <h2>最近情緒紀錄</h2>
        <div className="timeline">
          {history.length === 0 ? (
            <p className="hint">尚無紀錄。</p>
          ) : (
            history.slice(-12).map((item, index) => (
              <div className="timeline-item" key={`${item.createdAt}-${index}`}>
                <span>{formatTime(item.createdAt)}</span>
                <strong>{item.emotion} / {getEmotionLabel(item.emotion)}</strong>
              </div>
            ))
          )}
        </div>
      </section>
    </main>
  );
}
