"""
情緒光譜 Module 4 Backend
FastAPI backend for Dashboard & Management.

重要修正：
- 不使用 ngrok token，也不把任何金鑰寫進程式碼。
- 不使用 Colab/Jupyter 的 !pip 指令。
- 不混用 Streamlit、Gradio、ngrok；正式前端改由 React 負責。
- 不使用 隨機函式 產生正式情緒結果；情緒資料必須由 Module II 傳入。
- 校正需要 Module I 提供的臉部基準特徵，不再只把 calibrated 設成 True。
- 不保存原始影像，只保存匿名編號、特徵摘要、情緒結果與信心度。
"""

from __future__ import annotations

import csv
import io
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from statistics import pstdev
from typing import Dict, List, Literal, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, field_validator, model_validator

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "emotion_spectrum.db"
MAX_RECORDS_PER_SUBJECT = 1000

Emotion = Literal["CALM", "JOY", "ANXIOUS", "DEPRESSED"]
DisplayMode = Literal["dashboard", "fullscreen"]

# 與隊友統一的情緒代碼：後端/API 使用英文 key，畫面顯示使用中文 label。
EMOTION_META: Dict[str, Dict[str, str]] = {
    "CALM": {"label": "平靜"},
    "JOY": {"label": "愉悅"},
    "ANXIOUS": {"label": "緊張"},
    "DEPRESSED": {"label": "低落"},
}
EMOTIONS: List[str] = list(EMOTION_META.keys())

# Module I 應提供的特徵摘要欄位。這裡只存數值，不存照片或影片。
REQUIRED_BASELINE_FEATURES = [
    "mouth_corner_delta",      # 嘴角變化
    "eye_open_degree",         # 眼睛開合程度
    "brow_angle",              # 眉毛角度
    "head_pitch",              # 頭部上下角度
    "head_yaw",                # 頭部左右角度
    "landmark_variance",       # 臉部特徵點穩定度
]

VISUAL_STYLE_BY_EMOTION = {
    "CALM": {
        "label": "平靜",
        "palette": ["#1e3a8a", "#60a5fa"],
        "background": "soft_blue_gradient",
        "animation": "slow_breathing",
        "animationSpeedMs": 3800,
        "brightness": 0.86,
        "contrast": 0.72,
        "pulseIntensity": 0.14,
    },
    "JOY": {
        "label": "愉悅",
        "palette": ["#f59e0b", "#fde68a"],
        "background": "warm_orange_gradient",
        "animation": "warm_particles",
        "animationSpeedMs": 2400,
        "brightness": 0.92,
        "contrast": 0.78,
        "pulseIntensity": 0.22,
    },
    "ANXIOUS": {
        "label": "緊張",
        "palette": ["#991b1b", "#f87171"],
        "background": "red_pulse_gradient",
        "animation": "controlled_pulse",
        "animationSpeedMs": 1200,
        "brightness": 0.82,
        "contrast": 0.70,
        "pulseIntensity": 0.28,
    },
    "DEPRESSED": {
        "label": "低落",
        "palette": ["#312e81", "#7c3aed"],
        "background": "low_light_purple_flow",
        "animation": "slow_flow",
        "animationSpeedMs": 4200,
        "brightness": 0.64,
        "contrast": 0.62,
        "pulseIntensity": 0.10,
    },
}


class CalibrationRequest(BaseModel):
    subjectId: str = Field(..., min_length=1, max_length=32)
    baselineFeatures: Dict[str, float]

    @field_validator("subjectId")
    @classmethod
    def validate_subject_id(cls, value: str) -> str:
        return sanitize_subject_id(value)

    @model_validator(mode="after")
    def validate_baseline_features(self) -> "CalibrationRequest":
        missing = [key for key in REQUIRED_BASELINE_FEATURES if key not in self.baselineFeatures]
        if missing:
            raise ValueError("缺少 Module I 基準特徵欄位：" + ", ".join(missing))
        return self


class EmotionUpdateRequest(BaseModel):
    subjectId: str = Field(..., min_length=1, max_length=32)
    probabilities: Dict[Emotion, float]
    featureDelta: Optional[Dict[str, float]] = None
    source: str = Field(default="module_ii", max_length=32)

    @field_validator("subjectId")
    @classmethod
    def validate_subject_id(cls, value: str) -> str:
        return sanitize_subject_id(value)

    @model_validator(mode="after")
    def validate_probabilities(self) -> "EmotionUpdateRequest":
        missing = [emotion for emotion in EMOTIONS if emotion not in self.probabilities]
        if missing:
            raise ValueError("缺少情緒信心度欄位：" + ", ".join(missing))

        for emotion, value in self.probabilities.items():
            if value < 0:
                raise ValueError(f"{emotion} 信心度不可小於 0")

        total = sum(float(v) for v in self.probabilities.values())
        if total <= 0:
            raise ValueError("四個信心度加總必須大於 0")
        return self


class PauseRequest(BaseModel):
    subjectId: str = Field(..., min_length=1, max_length=32)
    paused: bool

    @field_validator("subjectId")
    @classmethod
    def validate_subject_id(cls, value: str) -> str:
        return sanitize_subject_id(value)


class DisplayModeRequest(BaseModel):
    subjectId: str = Field(..., min_length=1, max_length=32)
    mode: DisplayMode

    @field_validator("subjectId")
    @classmethod
    def validate_subject_id(cls, value: str) -> str:
        return sanitize_subject_id(value)


app = FastAPI(title="情緒光譜 Module 4 API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sanitize_subject_id(subject_id: str) -> str:
    """避免 CSV 檔名或查詢條件出現不安全字元。"""
    cleaned = re.sub(r"[^A-Za-z0-9_-]", "_", subject_id.strip())
    cleaned = cleaned[:32]
    if not cleaned:
        raise ValueError("受試者編號不可為空")
    return cleaned


@contextmanager
def db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with db_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS subjects (
                subject_id TEXT PRIMARY KEY,
                calibrated_at TEXT NOT NULL,
                baseline_json TEXT NOT NULL,
                is_paused INTEGER NOT NULL DEFAULT 0,
                display_mode TEXT NOT NULL DEFAULT 'dashboard',
                last_result_json TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS emotion_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject_id TEXT NOT NULL,
                created_at TEXT NOT NULL,
                emotion TEXT NOT NULL,
                confidence_json TEXT NOT NULL,
                feature_delta_json TEXT,
                display_mode TEXT NOT NULL,
                visual_config_json TEXT NOT NULL,
                safety_config_json TEXT NOT NULL,
                FOREIGN KEY(subject_id) REFERENCES subjects(subject_id)
            )
            """
        )


@app.on_event("startup")
def on_startup() -> None:
    init_db()


def normalize_probabilities(probabilities: Dict[str, float]) -> Dict[str, float]:
    """將 Module II 傳來的四類情緒信心度正規化為總和 100%。"""
    total = sum(float(probabilities[emotion]) for emotion in EMOTIONS)
    return {
        emotion: round(float(probabilities[emotion]) / total * 100, 2)
        for emotion in EMOTIONS
    }


def choose_emotion(probabilities: Dict[str, float]) -> str:
    """目前情緒永遠取信心度最高者，避免標籤與信心度不一致。"""
    return max(EMOTIONS, key=lambda emotion: probabilities[emotion])


def build_visual_config(emotion: str) -> Dict[str, object]:
    return dict(VISUAL_STYLE_BY_EMOTION[emotion])


def apply_visual_safety(visual_config: Dict[str, object]) -> Dict[str, object]:
    """
    真的回傳可給 Module III/React 套用的安全控制參數，
    而不是只顯示文字。
    """
    safe_config = dict(visual_config)
    safe_config["animationSpeedMs"] = max(int(safe_config["animationSpeedMs"]), 1200)
    safe_config["brightness"] = min(float(safe_config["brightness"]), 0.92)
    safe_config["contrast"] = min(float(safe_config["contrast"]), 0.78)
    safe_config["pulseIntensity"] = min(float(safe_config["pulseIntensity"]), 0.28)
    safe_config["flashAllowed"] = False
    return safe_config


def get_subject_or_404(conn: sqlite3.Connection, subject_id: str) -> sqlite3.Row:
    row = conn.execute(
        "SELECT * FROM subjects WHERE subject_id = ?",
        (subject_id,),
    ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="找不到受試者，請先完成校正")
    return row


def fetch_history(conn: sqlite3.Connection, subject_id: str, limit: int = 50) -> List[Dict[str, object]]:
    rows = conn.execute(
        """
        SELECT created_at, emotion, confidence_json, display_mode
        FROM emotion_records
        WHERE subject_id = ?
        ORDER BY id DESC
        LIMIT ?
        """,
        (subject_id, limit),
    ).fetchall()

    history = []
    for row in reversed(rows):
        confidence = json.loads(row["confidence_json"])
        history.append(
            {
                "createdAt": row["created_at"],
                "emotion": row["emotion"],
                "emotionLabel": EMOTION_META.get(row["emotion"], {}).get("label", row["emotion"]),
                "confidence": confidence,
                "displayMode": row["display_mode"],
            }
        )
    return history


def build_trend_summary(history: List[Dict[str, object]]) -> Dict[str, object]:
    """
    不把情緒硬編成 1~4 的高低順序。
    改用：情緒切換次數、平均最高信心度、最近主情緒分布。
    """
    if not history:
        return {
            "recordCount": 0,
            "switchCount": 0,
            "averageTopConfidence": 0,
            "dominantDistribution": {emotion: 0 for emotion in EMOTIONS},
            "note": "尚無資料。",
        }

    emotions = [item["emotion"] for item in history]
    switch_count = sum(1 for prev, curr in zip(emotions, emotions[1:]) if prev != curr)
    top_confidences = [max(item["confidence"].values()) for item in history]
    distribution = {emotion: emotions.count(emotion) for emotion in EMOTIONS}

    stability_note = "情緒狀態穩定"
    if len(top_confidences) >= 3 and pstdev(top_confidences) > 15:
        stability_note = "信心度波動較大，建議延長觀察時間"
    if switch_count >= max(2, len(history) // 3):
        stability_note = "主情緒切換較頻繁，可能存在短時間波動"

    return {
        "recordCount": len(history),
        "switchCount": switch_count,
        "averageTopConfidence": round(sum(top_confidences) / len(top_confidences), 2),
        "dominantDistribution": distribution,
        "note": stability_note,
    }


def trim_old_records(conn: sqlite3.Connection, subject_id: str) -> None:
    conn.execute(
        """
        DELETE FROM emotion_records
        WHERE id IN (
            SELECT id FROM emotion_records
            WHERE subject_id = ?
            ORDER BY id DESC
            LIMIT -1 OFFSET ?
        )
        """,
        (subject_id, MAX_RECORDS_PER_SUBJECT),
    )


@app.get("/api/health")
def health_check() -> Dict[str, str]:
    return {"status": "ok", "service": "情緒光譜 Module 4 API"}


@app.post("/api/calibration")
def calibrate(payload: CalibrationRequest) -> Dict[str, object]:
    """
    接收 Module I 輸出的個人化基準特徵。
    只有拿到基準特徵才算完成校正。
    """
    now = utc_now_iso()
    baseline_json = json.dumps(payload.baselineFeatures, ensure_ascii=False)

    with db_connection() as conn:
        conn.execute(
            """
            INSERT INTO subjects (subject_id, calibrated_at, baseline_json, is_paused, display_mode, last_result_json)
            VALUES (?, ?, ?, 0, 'dashboard', NULL)
            ON CONFLICT(subject_id) DO UPDATE SET
                calibrated_at = excluded.calibrated_at,
                baseline_json = excluded.baseline_json,
                is_paused = 0
            """,
            (payload.subjectId, now, baseline_json),
        )

    return {
        "subjectId": payload.subjectId,
        "calibrated": True,
        "calibratedAt": now,
        "message": "校正完成：已建立個人化基準特徵，未保存原始影像。",
    }


@app.post("/api/emotion")
def receive_emotion(payload: EmotionUpdateRequest) -> Dict[str, object]:
    """
    接收 Module II 的正式情緒輸出。
    這裡不使用假資料，不使用 random。
    """
    with db_connection() as conn:
        subject = get_subject_or_404(conn, payload.subjectId)
        if bool(subject["is_paused"]):
            last = json.loads(subject["last_result_json"]) if subject["last_result_json"] else None
            return {
                "accepted": False,
                "paused": True,
                "message": "目前已暫停分析，保留上一筆分析狀態。",
                "lastResult": last,
            }

        normalized = normalize_probabilities(payload.probabilities)
        emotion = choose_emotion(normalized)
        visual_config = build_visual_config(emotion)
        safety_config = apply_visual_safety(visual_config)
        now = utc_now_iso()

        record_json = {
            "subjectId": payload.subjectId,
            "createdAt": now,
            "emotion": emotion,
            "emotionLabel": EMOTION_META[emotion]["label"],
            "confidence": normalized,
            "displayMode": subject["display_mode"],
            "visualConfig": visual_config,
            "safetyConfig": safety_config,
        }

        conn.execute(
            """
            INSERT INTO emotion_records (
                subject_id, created_at, emotion, confidence_json,
                feature_delta_json, display_mode, visual_config_json, safety_config_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload.subjectId,
                now,
                emotion,
                json.dumps(normalized, ensure_ascii=False),
                json.dumps(payload.featureDelta, ensure_ascii=False) if payload.featureDelta else None,
                subject["display_mode"],
                json.dumps(visual_config, ensure_ascii=False),
                json.dumps(safety_config, ensure_ascii=False),
            ),
        )
        conn.execute(
            "UPDATE subjects SET last_result_json = ? WHERE subject_id = ?",
            (json.dumps(record_json, ensure_ascii=False), payload.subjectId),
        )
        trim_old_records(conn, payload.subjectId)

        history = fetch_history(conn, payload.subjectId, limit=50)

    return {
        "accepted": True,
        "result": record_json,
        "history": history,
        "trendSummary": build_trend_summary(history),
    }


@app.post("/api/pause")
def set_pause(payload: PauseRequest) -> Dict[str, object]:
    with db_connection() as conn:
        get_subject_or_404(conn, payload.subjectId)
        conn.execute(
            "UPDATE subjects SET is_paused = ? WHERE subject_id = ?",
            (1 if payload.paused else 0, payload.subjectId),
        )
        subject = get_subject_or_404(conn, payload.subjectId)
        last = json.loads(subject["last_result_json"]) if subject["last_result_json"] else None

    return {
        "subjectId": payload.subjectId,
        "paused": payload.paused,
        "lastResult": last,
        "message": "已暫停，畫面保留上一筆狀態。" if payload.paused else "已繼續分析。",
    }


@app.post("/api/display-mode")
def set_display_mode(payload: DisplayModeRequest) -> Dict[str, object]:
    with db_connection() as conn:
        get_subject_or_404(conn, payload.subjectId)
        conn.execute(
            "UPDATE subjects SET display_mode = ? WHERE subject_id = ?",
            (payload.mode, payload.subjectId),
        )
    return {"subjectId": payload.subjectId, "displayMode": payload.mode}


@app.get("/api/state/{subject_id}")
def get_state(subject_id: str, limit: int = Query(default=50, ge=1, le=200)) -> Dict[str, object]:
    subject_id = sanitize_subject_id(subject_id)
    with db_connection() as conn:
        subject = get_subject_or_404(conn, subject_id)
        history = fetch_history(conn, subject_id, limit=limit)
        last = json.loads(subject["last_result_json"]) if subject["last_result_json"] else None

    return {
        "subjectId": subject_id,
        "calibrated": True,
        "paused": bool(subject["is_paused"]),
        "displayMode": subject["display_mode"],
        "lastResult": last,
        "history": history,
        "trendSummary": build_trend_summary(history),
        "privacy": "系統只保存匿名編號、特徵摘要、情緒結果與信心度，不保存原始影像。",
    }


@app.get("/api/report/{subject_id}")
def export_report(subject_id: str) -> StreamingResponse:
    subject_id = sanitize_subject_id(subject_id)
    with db_connection() as conn:
        get_subject_or_404(conn, subject_id)
        rows = conn.execute(
            """
            SELECT created_at, emotion, confidence_json, display_mode
            FROM emotion_records
            WHERE subject_id = ?
            ORDER BY id ASC
            """,
            (subject_id,),
        ).fetchall()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "受試者編號",
        "時間",
        "主情緒代碼",
        "主情緒中文",
        "CALM(平靜)信心度",
        "JOY(愉悅)信心度",
        "ANXIOUS(緊張)信心度",
        "DEPRESSED(低落)信心度",
        "展示模式",
    ])

    for row in rows:
        confidence = json.loads(row["confidence_json"])
        writer.writerow([
            subject_id,
            row["created_at"],
            row["emotion"],
            EMOTION_META.get(row["emotion"], {}).get("label", row["emotion"]),
            confidence["CALM"],
            confidence["JOY"],
            confidence["ANXIOUS"],
            confidence["DEPRESSED"],
            row["display_mode"],
        ])

    csv_bytes = output.getvalue().encode("utf-8-sig")
    filename = f"emotion_report_{subject_id}.csv"

    return StreamingResponse(
        io.BytesIO(csv_bytes),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
