# Security Note

## 已移除的危險內容

- 不再硬編 ngrok auth token。
- 不使用公開 tunnel。
- 不在程式中保存任何 API key 或 token。

## 如果 token 曾經公開上傳

請立即完成：

1. 到 ngrok 後台撤銷原本的 token。
2. 不要再使用那組 token。
3. 清除 Git history，或建立新的乾淨 repository。
4. 之後需要金鑰時，只能放在 `.env` 或部署平台的環境變數，不要寫進程式碼。

## 隱私設計

本專案只保存：

- 受試者匿名編號
- Module I 輸出的臉部特徵摘要
- Module II 輸出的情緒信心度
- Dashboard 狀態與報告資料

本專案不保存：

- 原始照片
- 原始影片
- 可識別身分的個資
