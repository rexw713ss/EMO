# 情緒光譜：Module 4 儀表板與後台管理功能

這份是依照 15 點問題重新整理後的正式版本。

## 這版修掉的重點

1. 移除 ngrok auth token，程式碼內不再出現任何金鑰。
2. 移除 `!pip install`，改用 `requirements.txt`。
3. 補上 backend 的 `requirements.txt`。
4. 不再執行不存在的 `streamlit run app.py`。
5. 不混用 Streamlit、Gradio、ngrok；正式前端改成 React。
6. 情緒結果不再使用 `隨機函式`，必須由 Module II 傳入。
7. 四類信心度會正規化成總和 100%，主情緒永遠取最高信心度。
8. 校正必須收到 Module I 的臉部特徵基準資料。
9. 暫停時保留上一筆狀態，不會把圖表歸零。
10. 趨勢不再把情緒硬編成 1～4，而是顯示各類信心度時間軸與情緒切換次數。
11. records 改用 SQLite 持久化，不使用全域記憶體陣列。
12. CSV 匯出檔名會清理 subject ID 特殊字元。
13. 移除 Matplotlib，避免長時間建立圖表造成記憶體累積。
14. 視覺安全模式會回傳實際動畫速度、亮度、對比與禁止閃爍設定，React 前端會套用。
15. Gradio 舊版只當需求參考，正式前端為 React。

## 安全提醒：ngrok token 一定要撤銷

原本 token 如果已經推到公開 GitHub，不能只刪程式碼，因為 commit history 裡仍然找得到。請到 ngrok 後台撤銷該 token，然後再處理 GitHub 歷史紀錄或建立乾淨的新 repo。

## 專案結構

```text
backend/
  main.py
  requirements.txt
  sample_module2_payload.json
frontend/
  package.json
  index.html
  src/
    main.jsx
    App.jsx
    styles.css
```

## 執行後端 Python FastAPI

Windows PowerShell：

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

打開後端文件測試頁：

```text
http://127.0.0.1:8000/docs
```

## 執行前端 React

另開一個 PowerShell：

```powershell
cd frontend
npm install
npm run dev
```

開瀏覽器：

```text
http://127.0.0.1:5173
```

## 正式串接方式

- Module I：把臉部基準特徵傳到 `/api/calibration`
- Module II：把情緒信心度傳到 `/api/emotion`
- 情緒代碼已統一為隊友格式：`CALM`=平靜、`JOY`=愉悅、`ANXIOUS`=緊張、`DEPRESSED`=低落
- Module III：可使用後端回傳的 `safetyConfig` 與 `visualConfig` 控制螢幕動畫
- Module IV：React Dashboard 顯示狀態、圖表、趨勢、控制與 CSV 匯出

## 注意

這份不包含真正的攝影機模型與 AI 模型。它只負責 Module 4：Dashboard 與管理後台。AI 情緒結果需要 Module II 傳入。


## Module II 傳入格式範例

```json
{
  "subjectId": "SUBJECT_001",
  "probabilities": {
    "CALM": 15,
    "JOY": 72,
    "ANXIOUS": 8,
    "DEPRESSED": 5
  },
  "source": "module_ii"
}
```

前端內部也使用相同 key：

```javascript
const EMOTION_META = {
  CALM: { label: '平靜' },
  JOY: { label: '愉悅' },
  ANXIOUS: { label: '緊張' },
  DEPRESSED: { label: '低落' },
};
```
